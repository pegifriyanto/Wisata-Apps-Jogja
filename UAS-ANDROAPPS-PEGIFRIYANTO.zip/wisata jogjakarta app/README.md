### Table of Contents
- [Description](#description)
- [Features](#features)
- [Data](#data)
---

### Description
This project used for submitting submission Dicoding IDCamp - Android Pemula

---


### Features
- Splash Screen
- List News
- Detail News
- About Me
- Share
---
   
### Data
Data in application from : https://github.com/satyawikananda/berita-indo-api



